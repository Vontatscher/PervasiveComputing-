struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        // TODO: Write a response
        
        if question == "hello there" {
            return "Why, hello there!"
        }else if question.hasSuffix("your name"){
            return "My Name is Lilo"
        }else if question == "how old are you?"{
            return "I'm as old as any wise person"
        }else if question == "where is Mexico?"{
            return "In Latinamerica"
        }else if question.hasPrefix("where"){
            return "in this planet"
        }else if question.hasPrefix("how"){
            return "Only God knows how"
        }else if question.hasPrefix("what"){
            return "WTF! Next question"
        }else if question.hasPrefix("who"){
            return "Who ever you think it is"
        }else{
            return "I'm tired of your questions, bye"
        }
    }
}

