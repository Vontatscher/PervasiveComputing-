//
//  ViewController.swift
//  AnimalSounds
//
//  Created by Karen Fontecha Torre on 4/27/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
// las constantes de los sonidos
    let meowSound = SimpleSound(named: "meow")
    let woofSound = SimpleSound(named: "woof")
    let mooSound = SimpleSound(named: "moo")

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var animalSoundLabel: UILabel!
    
    @IBAction func cowButtonTapped(_ sender: Any) {
         animalSoundLabel.text = "Mooo!"
        mooSound.play()
    }
    @IBAction func dogButtonTapped(_ sender: Any) {
        animalSoundLabel.text = "Wouf!"
        woofSound.play()
    }
    @IBAction func catButtonTapped(_ sender: Any) {
        animalSoundLabel.text = "Meow!"
        meowSound.play()
    }
}

