//
//  GameState.swift
//  RPS
//
//  Created by Karen Fontecha Torre on 4/28/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import Foundation


enum GameState {
    case start
    case win
    case lose
    case draw
    
    var status: String {
        switch self {
        case .start:
            return "Rock, Paper, Scissors?"
        case .win:
            return "You Won!"
        case .lose:
            return "You Lost!"
        case .draw:
            return "It's a Draw!"
        }
    }
}

