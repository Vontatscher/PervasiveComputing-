//
//  Sign.swift
//  RPS
//
//  Created by Karen Fontecha Torre on 4/28/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//
import GameplayKit // importing an API
import Foundation

//Add the following line at the top level
let randomChoice = GKRandomDistribution(lowestValue: 0, highestValue: 2)

func randomSign() -> Sign {
    let sign = randomChoice.nextInt()
    if sign == 0 {
        return .rock
    } else if sign == 1 {
        return .paper
    } else {
        return .scissors
    }
}

// primera parte: crear un enum llamado sign con las diferentes señaes
enum Sign {
    case rock
    case paper
    case scissors
    
    // Agregar una calculates property to give the emoji that represents the sign
    var textValue: String{
        //You can use the postfix self expression to access a type as a value itself
        // se usa el self para que recorra el enum de Sign
    switch self {
    case .rock: return "👊"
    case .paper: return "✋"
    case .scissors: return "✌️"
        }
    }
    
    //create an instance method to sign that takes another sign, representing the opponent turn as a paramenter. The method should return a GameState based on the comparison.
    func gameState(versusSign: Sign) -> GameState {
        if self == versusSign {
            return .draw
        }
    switch self {
    case .rock:
        if versusSign == .scissors {
            return .win
        }
    case .paper:
        if versusSign == .rock {
            return .win
        }
    case .scissors:
        if versusSign == .paper {
            return .win
        }
    }
    return .lose
    }
}

