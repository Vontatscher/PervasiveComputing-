//
//  ViewController.swift
//  programaic segue
//
//  Created by Karen Fontecha Torre on 4/3/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func greenButtonTapped(_ sender: Any) {
        if segueSwitch.isOn {
            //nil significa nulo
            performSegue(withIdentifier: "Green", sender: nil)
        }
    }
    
    @IBAction func yellowButtonTapped(_ sender: Any) {
        if segueSwitch.isOn {
            //nil significa nulo
            performSegue(withIdentifier: "Yellow", sender: nil)
            }
    }
    
    @IBOutlet weak var segueSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

