//
//  ViewController.swift
//  SinglePhoto
//
//  Created by Karen Fontecha Torre on 3/2/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

