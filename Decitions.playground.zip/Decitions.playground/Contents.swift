import UIKit
var str = "Hello, playground"

true
false

5 == 5
5 == 6

var video = 8
if video < 10 {
    print("el video dura mucho")
}
else if video > 500 {
print("esta super largo")
}
else{
    print("no esta tan largo")
}


var hola = "hola buenos dias"
var numero = 0

hola.hasPrefix("hola")
//numero.hasPrefix

hola.isEmpty
hola.removeAll()
hola.isEmpty

/////////////////

var devices = ["ipad", "imac", "iphone", "ipod"]
devices[1]

let numeros = [6,4,2,4,6,7,4,6]
print("yo tengo un \(devices[0])")


let friends = ["Luis", "Pedro", "Juan", "Pablo"]

for friend in friends {
    let sparklyFriend = "🎈\(friend) 🥳 "
    print("Oye, \(sparklyFriend), te invito a mi fiesta el viernes")
    
}
print("Listo, invitaste a todos tus amigos")

devices.append("mac mini")
devices.insert("apple TV", at: 0)

devices += ["macbook","macbook pro"]
devices.remove(at:0)
devices.removeFirst()
