import UIKit

// enumeradores
enum comida {
    case pasta
    case hambuerguesa
    case sopa
}

let restaurante = comida.hambuerguesa
print(restaurante)

// es lo mismo
enum comidaDos{
    case pescado, pollo, nuggets
}


/*var eleccion: comidaDos
eleccion = .pescado */

enum LunchChoice {
    case pasta, burger, soup
    
}

let myLunch = LunchChoice.burger
let yourLunch = LunchChoice.burger

if myLunch == yourLunch{
    "vamos a almorzar lo mismo"
}else{
    "Puedo probar tu comida"
}

func cookLunch(_ choice: LunchChoice) -> String {
    if choice == .pasta{
        return "🍝"
    }else if choice == .burger{
        return "🍔"
    }else if choice == .soup{
        return "🍲"
    }
    return "mmmm, ¿Cómo llegamos hasta aquí?"
}

let choice = LunchChoice.burger
switch choice {
case .pasta:
    " 🍝"
case .burger:
    " 🍔"
case .soup:
    " 🍲"
}

enum calidad {
    case bueno, regular, malo, muyMalo
}

let quality = calidad.bueno

switch quality{
case .muyMalo:
    print("No es aceptable" )
case  .malo:
    print("No es suficiente")
case .regular,.bueno:
     print("Bien, lo acepto")
}
