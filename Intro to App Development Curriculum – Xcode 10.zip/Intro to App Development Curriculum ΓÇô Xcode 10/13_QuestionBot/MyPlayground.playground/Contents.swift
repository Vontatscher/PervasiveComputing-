import UIKit

var str = "Hello, playground"
func responseTo(question: String) -> String {
    // TODO: Write a response
    
    if question == "hello there" {
        return "Why, hello there!"
    }else if question == "what's your name?"{
        return "My Name is Lilo"
    }else if question == "how old are you?"{
        return "I'm as old as any wise person"
    }else if question == "where is Mexico?"{
        return "In Latinamerica"
    }else if question.hasPrefix("where"){
        return "in this planet"
    }else if question.hasPrefix("how"){
        return "Only God knows how"
    }else if question.hasPrefix("what"){
        return "WTF! Next question"
    }else if question.hasPrefix("who"){
        return "Who ever you think it is"
    }else{
        return "I'm tired of your questions, bye"
    }
}
responseTo(question: "who are you")



/*
 struct MyQuestionAnswerer {
 func responseTo(question: String) -> String {
 let lowercasedQuestion = question.lowercased()
 if lowercasedQuestion == "hello there" {
 return "Why, hello there!"
 } else if lowercasedQuestion == "where are the cookies?" {
 return "In the cookie jar!"
 } else if lowercasedQuestion.hasPrefix("where") {
 return "To the North!"
 } else {
 let defaultNumber = question.characters.count % 3
 
 if defaultNumber == 0 {
 return "That really depends"
 } else if defaultNumber == 1 {
 return "Ask me again tomorrow"
 } else { // 2
 return "I'm not sure I understand"
 }
 }
 }
 }
 */
