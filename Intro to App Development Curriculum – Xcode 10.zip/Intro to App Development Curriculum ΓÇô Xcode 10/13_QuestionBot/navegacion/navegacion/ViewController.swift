//
//  ViewController.swift
//  navegacion
//
//  Created by Karen Fontecha Torre on 4/1/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //Le estoy indicando que el texto se vaya a la siguiente pantalla.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination.navigationItem.title = textField.text
    }
    @IBAction func unwindToPink (unwindSegue: UIStoryboardSegue){
    
    }

}

