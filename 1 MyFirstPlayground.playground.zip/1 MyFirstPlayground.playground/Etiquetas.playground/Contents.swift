 import UIKit

//var str = "Hello, playground"
//print(str)
//comment
//var 😍 = "HAPPY"
//print(😍)

 //let favoriteBook = "The Sun Also Rises"
 //str = "Hello, Karen"
 //print(str)

 let age = 25
 let months = 2
 let name = "Karen"
 let firstName = "Fontecha De la Torre"
 let birthday = "14-02-1994"
 let isHappy = true
// func hello( name nombre:String) { // anotacion de Tipo
    func hello( name nombre:String) -> String{
        let saludo = "hola" + nombre
return saludo
    // let name = "Anjia" // va a  agarrar la del contexto más cercano
   // print ("Hola " + nombre) // aplicando concatenación, por eso se le tiene que poner espacio despues del hola
   // print ("Hola",  name) // respeta el espacio
    //print ("Hola \(name)") // se hace una interpolación
 }
 hello(name:"Eileen")
