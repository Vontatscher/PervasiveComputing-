//
//  SouvenirViewController.swift
//  examen3
//
//  Created by Karen Fontecha Torre on 5/21/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class SouvenirViewController: UIViewController {
    @IBOutlet weak var codeField: UITextField!
    
    var countCups: Double = 0
    var countTShirts: Double = 0
    let promoCode: String = "AA7467B"
    
    var totalPrice: Double = 0 {
        willSet {
            totalPriceLabel.text = "\(newValue)"
        }
    }
    
    
    @IBOutlet weak var StepperCup: UIStepper!
    @IBOutlet weak var StepperTShirt: UIStepper!
    
    @IBOutlet weak var numberOfTshirts: UILabel!
    @IBOutlet weak var numberOfCups: UILabel!
    
    
    @IBOutlet weak var totalPriceLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func changedTshirtCount(_ sender: UIStepper) {
        //print(sender.value)
        numberOfTshirts.text = "\(sender.value)"
        countTShirts = sender.value
        totalPrice = (countTShirts*15)+(countCups*5)
        
        
    }
    @IBAction func changedCupCount(_ sender: UIStepper) {
        //print(sender.value)
        numberOfCups.text = "\(sender.value)"
        countCups = sender.value
        totalPrice = (countTShirts*15)+(countCups*5)
        
    }
    
    @IBAction func validate(_ sender: Any) {
        
        var title = ""
        var message = ""
        
        if(codeField.text == promoCode){
            
            message = "You have received 50% off in your total price. TOTAL PRICE \(totalPrice/2)"
            
            title = "Congrats"
            
            
        }else{
            title = "Sorry!"
            message = "Invalid code"
            
        }
        
        let ac = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let alert = UIAlertAction(title: "ok", style: .default)
        
        ac.addAction(alert)
        
        present(ac, animated: true)
    }
    
    
    
    

    
    
    
    

}
