//
//  Ab1ViewController.swift
//  examen3
//
//  Created by Karen Fontecha Torre on 5/22/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class Ab1ViewController: UIViewController {
    
     let album1Sound = SimpleSound(named: "album1.mp3")
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func listenButtonTapped(_ sender: Any) {
        album1Sound.play()
    }
    


}
