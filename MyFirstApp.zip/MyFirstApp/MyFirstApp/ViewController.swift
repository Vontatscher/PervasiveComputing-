//
//  ViewController.swift
//  MyFirstApp
//
//  Created by Karen Fontecha Torre on 3/4/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func buttonTrapped(_ sender: UIButton) {
        
        label.text = " \"Hola\""
        view.backgroundColor = UIColor.lightGray
       
    }
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

