//
//  ViewController.swift
//  SimpleCenter
//
//  Created by Karen Fontecha Torre on 4/4/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

