 import UIKit

 let age = 25
 let months = 2
 let name = "Karen"
 let firstName = "Fontecha De la Torre"
 let birthday = Date(timeIntervalSinceNow: 3600)

    func hello( name nombre:String) -> String{
        let saludo:String = "Hola" + nombre
        return saludo
 }
let saludo: String = hello(name: "Anjia")

print(birthday)
