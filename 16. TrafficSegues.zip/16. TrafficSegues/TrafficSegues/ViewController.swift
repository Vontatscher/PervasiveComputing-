//
//  ViewController.swift
//  TrafficSegues
//
//  Created by Karen Fontecha Torre on 4/28/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // CODIGO PARA PROGRAMAR UN SEGUE PROGRAMADO
    @IBOutlet weak var segueSwitch: UISwitch!
    
    @IBAction func yellowButtonTapped(_ sender: Any) {
        if segueSwitch.isOn{
            //nil es como ninguno. No se necesita en este ejemplo
            performSegue(withIdentifier: "Yellow", sender: nil)
        }
    }
    
    @IBAction func greenButtonTapped(_ sender: Any) {
        if segueSwitch.isOn{
            performSegue(withIdentifier: "Green", sender: nil)
        }
    }
    


    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    /*creado un unwind SEGUE
     // @IBAction func unwindToRed(unwindSegue: UIStoryboardSegue) {
     }
     
    //aqui esta el Text Field
    // @IBOutlet weak var textField: UITextField!
    
    Preparando un Segue
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     //   segue.destination.navigationItem.title = textField.text
     }
      */
        
    }
    
  



