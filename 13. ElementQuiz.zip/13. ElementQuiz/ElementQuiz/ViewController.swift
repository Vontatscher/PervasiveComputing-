//
//  ViewController.swift
//  ElementQuiz
//
//  Created by Karen Fontecha Torre on 4/4/19.
//  Copyright © 2019 Karen Fontecha Torre. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var answerLabel: UILabel!
    
    let elementList = ["Carbon","Gold","Chlorine","Sodium"]
    // To track which element is currently displayed
    var currentElementIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //To show the first element of the list when the app launches
        updateElement()
        // Do any additional setup after loading the view.
    }
    
    func updateElement(){
        // set the text of the answer label to a question mark
        answerLabel.text = "?"
        // access the current element
        let elementName = elementList[currentElementIndex]
        // creates a new UII image instance
        let image = UIImage(named: elementName)
        //Set the image of the image view to the newly created image instance
        imageView.image = image
    }

    @IBAction func showAnswer(_ sender: Any) {
         answerLabel.text = elementList[currentElementIndex]
    }
    
    @IBAction func gotonextElement(_ sender: Any) {
        currentElementIndex += 1
        if currentElementIndex >= elementList.count {
            currentElementIndex = 0
        }
        updateElement()
    }
    
    
}

